from __future__ import annotations

from collections.abc import Callable, Iterable, Mapping
from typing import Any, TypeVar

T = TypeVar("T")


def ask(prompt: str, parser: Callable[[str], T]) -> T:
    """Repeatedly prompt until the supplied parser accepts the input."""

    while True:
        try:
            return parser(input(prompt))
        except (ValueError, TypeError) as error:
            print(f"Invalid input: {error}")


def pause() -> None:
    input("\nPress Enter to continue...")


def print_title(title: str) -> None:
    line = "=" * len(title)
    print(f"\n{title}\n{line}")


def print_menu(options: Mapping[str, str]) -> None:
    print_title("Employee and Department CRUD")
    for key, label in options.items():
        print(f"{key:>2}. {label}")


def render_table(rows: Iterable[dict[str, Any]], columns: list[tuple[str, str]]) -> None:
    materialized = list(rows)
    if not materialized:
        print("No records found.")
        return

    def display_value(value: Any) -> str:
        return "" if value is None else str(value)

    widths = {
        key: max(
            len(label),
            max(len(display_value(row.get(key))) for row in materialized),
        )
        for key, label in columns
    }

    header = " | ".join(label.ljust(widths[key]) for key, label in columns)
    divider = "-+-".join("-" * widths[key] for key, _ in columns)
    print(header)
    print(divider)

    formatted_rows = map(
        lambda row: " | ".join(
            display_value(row.get(key)).ljust(widths[key]) for key, _ in columns
        ),
        materialized,
    )
    print("\n".join(formatted_rows))
