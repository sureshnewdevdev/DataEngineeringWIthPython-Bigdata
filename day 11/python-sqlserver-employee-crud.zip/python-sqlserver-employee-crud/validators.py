from __future__ import annotations

from datetime import date, datetime
from decimal import Decimal, InvalidOperation
import re
from typing import Callable, TypeVar

T = TypeVar("T")

EMAIL_PATTERN = re.compile(r"^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$")


def non_empty(value: str) -> str:
    cleaned = value.strip()
    if not cleaned:
        raise ValueError("Value cannot be empty.")
    return cleaned


def positive_int(value: str) -> int:
    number = int(value)
    if number <= 0:
        raise ValueError("Enter a number greater than zero.")
    return number


def non_negative_decimal(value: str) -> Decimal:
    try:
        number = Decimal(value)
    except InvalidOperation as error:
        raise ValueError("Enter a valid numeric amount.") from error

    if number < 0:
        raise ValueError("Amount cannot be negative.")
    return number.quantize(Decimal("0.01"))


def valid_email(value: str) -> str:
    cleaned = non_empty(value).lower()
    if not EMAIL_PATTERN.fullmatch(cleaned):
        raise ValueError("Enter a valid email address.")
    return cleaned


def iso_date(value: str) -> date:
    try:
        return datetime.strptime(value.strip(), "%Y-%m-%d").date()
    except ValueError as error:
        raise ValueError("Use date format YYYY-MM-DD.") from error


def optional(parser: Callable[[str], T]) -> Callable[[str], T | None]:
    """Higher-order function: converts any parser into an optional parser."""

    def parse(value: str) -> T | None:
        return None if not value.strip() else parser(value)

    return parse


def choose(value: str, valid_choices: set[str]) -> str:
    selected = value.strip()
    if selected not in valid_choices:
        raise ValueError(f"Choose one of: {', '.join(sorted(valid_choices))}")
    return selected
