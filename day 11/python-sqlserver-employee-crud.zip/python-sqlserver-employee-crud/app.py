from __future__ import annotations

from decimal import Decimal
from typing import Callable

import pyodbc

from console_ui import ask, pause, print_menu, print_title, render_table
from database import create_database_and_tables, seed_sample_data
from repository import (
    create_department,
    create_employee,
    delete_department,
    delete_employee,
    get_department,
    get_employee,
    list_departments,
    list_employees,
    search_employees_by_department,
    update_department,
    update_employee,
)
from validators import (
    choose,
    iso_date,
    non_empty,
    non_negative_decimal,
    optional,
    positive_int,
    valid_email,
)

DEPARTMENT_COLUMNS = [
    ("department_id", "Dept ID"),
    ("department_name", "Department"),
    ("location", "Location"),
]

EMPLOYEE_COLUMNS = [
    ("employee_id", "Emp ID"),
    ("first_name", "First Name"),
    ("last_name", "Last Name"),
    ("email", "Email"),
    ("salary", "Salary"),
    ("hire_date", "Hire Date"),
    ("department_name", "Department"),
    ("location", "Location"),
]

MENU_OPTIONS = {
    "1": "Create database and tables",
    "2": "Insert sample data",
    "3": "Create department",
    "4": "Read/list departments",
    "5": "Update department",
    "6": "Delete department",
    "7": "Create employee",
    "8": "Read/list employees",
    "9": "Find employee by ID",
    "10": "Update employee",
    "11": "Delete employee",
    "12": "List employees by department",
    "0": "Exit",
}


def require_department(department_id: int) -> dict:
    department = get_department(department_id)
    if department is None:
        raise ValueError(f"Department ID {department_id} does not exist.")
    return department


def require_employee(employee_id: int) -> dict:
    employee = get_employee(employee_id)
    if employee is None:
        raise ValueError(f"Employee ID {employee_id} does not exist.")
    return employee


def setup_database_command() -> None:
    create_database_and_tables()
    print("Database and tables are ready.")


def seed_command() -> None:
    create_database_and_tables()
    seed_sample_data()
    print("Sample data inserted. Existing data was preserved.")


def create_department_command() -> None:
    print_title("Create Department")
    name = ask("Department name: ", non_empty)
    location = ask("Location (optional): ", optional(non_empty))
    department_id = create_department(name, location)
    print(f"Department created with ID {department_id}.")


def list_departments_command() -> None:
    print_title("Departments")
    render_table(list_departments(), DEPARTMENT_COLUMNS)


def update_department_command() -> None:
    print_title("Update Department")
    department_id = ask("Department ID: ", positive_int)
    current = require_department(department_id)

    print(f"Current name: {current['department_name']}")
    print(f"Current location: {current['location'] or ''}")

    name = ask("New department name: ", non_empty)
    location = ask("New location (optional): ", optional(non_empty))
    affected = update_department(department_id, name, location)
    print("Department updated." if affected else "Department was not updated.")


def delete_department_command() -> None:
    print_title("Delete Department")
    department_id = ask("Department ID: ", positive_int)
    department = require_department(department_id)
    confirmation = ask(
        f"Delete '{department['department_name']}'? (y/n): ",
        lambda value: choose(value.lower(), {"y", "n"}),
    )
    if confirmation == "n":
        print("Delete cancelled.")
        return

    affected = delete_department(department_id)
    print("Department deleted." if affected else "Department not found.")


def collect_employee_input(current: dict | None = None) -> tuple:
    if current:
        print(
            "Current values: "
            f"{current['first_name']} {current['last_name']}, "
            f"{current['email']}, salary={current['salary']}, "
            f"hire date={current['hire_date']}, "
            f"department={current['department_name']}"
        )

    first_name = ask("First name: ", non_empty)
    last_name = ask("Last name: ", non_empty)
    email = ask("Email: ", valid_email)
    salary = ask("Salary: ", non_negative_decimal)
    hire_date = ask("Hire date (YYYY-MM-DD): ", iso_date)

    render_table(list_departments(), DEPARTMENT_COLUMNS)
    department_id = ask("Department ID: ", positive_int)
    require_department(department_id)

    return first_name, last_name, email, salary, hire_date, department_id


def create_employee_command() -> None:
    print_title("Create Employee")
    values = collect_employee_input()
    employee_id = create_employee(*values)
    print(f"Employee created with ID {employee_id}.")


def list_employees_command() -> None:
    print_title("Employees")
    render_table(list_employees(), EMPLOYEE_COLUMNS)


def find_employee_command() -> None:
    print_title("Find Employee")
    employee_id = ask("Employee ID: ", positive_int)
    employee = get_employee(employee_id)
    render_table([] if employee is None else [employee], EMPLOYEE_COLUMNS)


def update_employee_command() -> None:
    print_title("Update Employee")
    employee_id = ask("Employee ID: ", positive_int)
    current = require_employee(employee_id)
    values = collect_employee_input(current)
    affected = update_employee(employee_id, *values)
    print("Employee updated." if affected else "Employee was not updated.")


def delete_employee_command() -> None:
    print_title("Delete Employee")
    employee_id = ask("Employee ID: ", positive_int)
    employee = require_employee(employee_id)
    confirmation = ask(
        f"Delete {employee['first_name']} {employee['last_name']}? (y/n): ",
        lambda value: choose(value.lower(), {"y", "n"}),
    )
    if confirmation == "n":
        print("Delete cancelled.")
        return

    affected = delete_employee(employee_id)
    print("Employee deleted." if affected else "Employee not found.")


def employees_by_department_command() -> None:
    print_title("Employees by Department")
    render_table(list_departments(), DEPARTMENT_COLUMNS)
    department_id = ask("Department ID: ", positive_int)
    require_department(department_id)
    render_table(search_employees_by_department(department_id), EMPLOYEE_COLUMNS)


def execute_command(command: Callable[[], None]) -> None:
    try:
        command()
    except pyodbc.IntegrityError as error:
        message = str(error)
        if "UQ_Employee_Email" in message:
            print("Database error: that employee email already exists.")
        elif "UQ_Department_DepartmentName" in message:
            print("Database error: that department name already exists.")
        elif "FK_Employee_Department" in message or "REFERENCE constraint" in message:
            print(
                "Database error: the department is referenced by employees. "
                "Move or delete those employees first."
            )
        else:
            print(f"Database integrity error: {error}")
    except pyodbc.Error as error:
        print(f"SQL Server error: {error}")
    except ValueError as error:
        print(f"Validation error: {error}")
    except Exception as error:
        print(f"Unexpected error: {error}")


def main() -> None:
    command_handlers: dict[str, Callable[[], None]] = {
        "1": setup_database_command,
        "2": seed_command,
        "3": create_department_command,
        "4": list_departments_command,
        "5": update_department_command,
        "6": delete_department_command,
        "7": create_employee_command,
        "8": list_employees_command,
        "9": find_employee_command,
        "10": update_employee_command,
        "11": delete_employee_command,
        "12": employees_by_department_command,
    }

    while True:
        print_menu(MENU_OPTIONS)
        choice = ask("\nChoose an option: ", lambda value: choose(value, set(MENU_OPTIONS)))

        if choice == "0":
            print("Application closed.")
            break

        execute_command(command_handlers[choice])
        pause()


if __name__ == "__main__":
    main()
