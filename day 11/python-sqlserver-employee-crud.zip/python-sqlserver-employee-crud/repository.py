from __future__ import annotations

from datetime import date
from decimal import Decimal
from typing import Any

from database import run_read, run_scalar, run_write


def row_to_department(row: Any) -> dict[str, Any]:
    return {
        "department_id": row.DepartmentId,
        "department_name": row.DepartmentName,
        "location": row.Location,
    }


def row_to_employee(row: Any) -> dict[str, Any]:
    return {
        "employee_id": row.EmployeeId,
        "first_name": row.FirstName,
        "last_name": row.LastName,
        "email": row.Email,
        "salary": row.Salary,
        "hire_date": row.HireDate,
        "department_id": row.DepartmentId,
        "department_name": row.DepartmentName,
        "location": row.Location,
    }


# --------------------------- Department CRUD ---------------------------

def create_department(name: str, location: str | None) -> int:
    return int(
        run_scalar(
            """
            INSERT INTO dbo.Department (DepartmentName, Location)
            OUTPUT INSERTED.DepartmentId
            VALUES (?, ?);
            """,
            (name, location),
        )
    )


def list_departments() -> list[dict[str, Any]]:
    return run_read(
        """
        SELECT DepartmentId, DepartmentName, Location
        FROM dbo.Department
        ORDER BY DepartmentName;
        """,
        mapper=row_to_department,
    )


def get_department(department_id: int) -> dict[str, Any] | None:
    rows = run_read(
        """
        SELECT DepartmentId, DepartmentName, Location
        FROM dbo.Department
        WHERE DepartmentId = ?;
        """,
        (department_id,),
        mapper=row_to_department,
    )
    return next(iter(rows), None)


def update_department(
    department_id: int,
    name: str,
    location: str | None,
) -> int:
    return run_write(
        """
        UPDATE dbo.Department
        SET DepartmentName = ?, Location = ?
        WHERE DepartmentId = ?;
        """,
        (name, location, department_id),
    )


def delete_department(department_id: int) -> int:
    return run_write(
        "DELETE FROM dbo.Department WHERE DepartmentId = ?;",
        (department_id,),
    )


# ----------------------------- Employee CRUD ----------------------------

def create_employee(
    first_name: str,
    last_name: str,
    email: str,
    salary: Decimal,
    hire_date: date,
    department_id: int,
) -> int:
    return int(
        run_scalar(
            """
            INSERT INTO dbo.Employee
                (FirstName, LastName, Email, Salary, HireDate, DepartmentId)
            OUTPUT INSERTED.EmployeeId
            VALUES (?, ?, ?, ?, ?, ?);
            """,
            (
                first_name,
                last_name,
                email,
                salary,
                hire_date,
                department_id,
            ),
        )
    )


def list_employees() -> list[dict[str, Any]]:
    return run_read(
        """
        SELECT
            e.EmployeeId,
            e.FirstName,
            e.LastName,
            e.Email,
            e.Salary,
            e.HireDate,
            e.DepartmentId,
            d.DepartmentName,
            d.Location
        FROM dbo.Employee AS e
        INNER JOIN dbo.Department AS d
            ON d.DepartmentId = e.DepartmentId
        ORDER BY e.EmployeeId;
        """,
        mapper=row_to_employee,
    )


def get_employee(employee_id: int) -> dict[str, Any] | None:
    rows = run_read(
        """
        SELECT
            e.EmployeeId,
            e.FirstName,
            e.LastName,
            e.Email,
            e.Salary,
            e.HireDate,
            e.DepartmentId,
            d.DepartmentName,
            d.Location
        FROM dbo.Employee AS e
        INNER JOIN dbo.Department AS d
            ON d.DepartmentId = e.DepartmentId
        WHERE e.EmployeeId = ?;
        """,
        (employee_id,),
        mapper=row_to_employee,
    )
    return next(iter(rows), None)


def update_employee(
    employee_id: int,
    first_name: str,
    last_name: str,
    email: str,
    salary: Decimal,
    hire_date: date,
    department_id: int,
) -> int:
    return run_write(
        """
        UPDATE dbo.Employee
        SET FirstName = ?,
            LastName = ?,
            Email = ?,
            Salary = ?,
            HireDate = ?,
            DepartmentId = ?,
            UpdatedAt = SYSUTCDATETIME()
        WHERE EmployeeId = ?;
        """,
        (
            first_name,
            last_name,
            email,
            salary,
            hire_date,
            department_id,
            employee_id,
        ),
    )


def delete_employee(employee_id: int) -> int:
    return run_write(
        "DELETE FROM dbo.Employee WHERE EmployeeId = ?;",
        (employee_id,),
    )


def search_employees_by_department(department_id: int) -> list[dict[str, Any]]:
    return run_read(
        """
        SELECT
            e.EmployeeId,
            e.FirstName,
            e.LastName,
            e.Email,
            e.Salary,
            e.HireDate,
            e.DepartmentId,
            d.DepartmentName,
            d.Location
        FROM dbo.Employee AS e
        INNER JOIN dbo.Department AS d
            ON d.DepartmentId = e.DepartmentId
        WHERE e.DepartmentId = ?
        ORDER BY e.FirstName, e.LastName;
        """,
        (department_id,),
        mapper=row_to_employee,
    )
