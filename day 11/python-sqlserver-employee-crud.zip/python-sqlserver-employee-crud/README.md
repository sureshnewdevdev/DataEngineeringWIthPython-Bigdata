# Python + SQL Server Employee CRUD

A menu-driven Python console application that:

- Connects to `DESKTOP-UHSE201\SQLEXPRESS` using Windows Integrated Security.
- Creates the `EmployeeManagementDB` database.
- Creates related `Department` and `Employee` tables.
- Implements Create, Read, Update, and Delete operations.
- Uses parameterized SQL, transactions, validation, and foreign keys.
- Demonstrates functional programming techniques.

## Relationship

```text
Department (1) --------------------< Employee (many)
DepartmentId PK                      DepartmentId FK
```

An employee must belong to one valid department. A department cannot be deleted while employees reference it.

## Prerequisites

1. SQL Server Express instance: `DESKTOP-UHSE201\SQLEXPRESS`
2. Python 3.10 or newer
3. Microsoft ODBC Driver 18 for SQL Server
4. Windows user permission to connect and create a database

Check the installed ODBC driver from Python:

```python
import pyodbc
print(pyodbc.drivers())
```

The list must contain:

```text
ODBC Driver 18 for SQL Server
```

## Setup in Windows PowerShell

```powershell
cd python-sqlserver-employee-crud

python -m venv .venv
.\.venv\Scripts\Activate.ps1

python -m pip install --upgrade pip
pip install -r requirements.txt

python app.py
```

If PowerShell blocks activation, run this once in the current terminal:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\.venv\Scripts\Activate.ps1
```

## First Run

From the menu:

1. Select **1 - Create database and tables**.
2. Optionally select **2 - Insert sample data**.
3. Use options **3–12** for CRUD operations.

## User Prompt Options

```text
 1. Create database and tables
 2. Insert sample data
 3. Create department
 4. Read/list departments
 5. Update department
 6. Delete department
 7. Create employee
 8. Read/list employees
 9. Find employee by ID
10. Update employee
11. Delete employee
12. List employees by department
 0. Exit
```

## Functional Programming Techniques Used

### 1. Small single-purpose functions

Database access, validation, formatting, prompts, and CRUD logic are separated into functions.

### 2. Pure functions

Examples:

- `build_connection_string`
- `non_empty`
- `valid_email`
- `iso_date`
- `row_to_employee`

These functions produce output from input without changing external state.

### 3. Immutable configuration

`DatabaseConfig` is a frozen dataclass, so database settings cannot be changed accidentally at runtime.

### 4. Higher-order functions

- `ask(prompt, parser)` receives another function for parsing and validation.
- `optional(parser)` converts a required parser into an optional parser.
- `run_read(..., mapper=...)` receives a row-mapping function.

### 5. First-class functions

The menu stores functions in `command_handlers` and executes the selected function without a long `if/elif` chain.

### 6. `map` and transformations

Database rows are mapped into dictionaries, and table rows are mapped into printable strings.

### 7. Side effects kept at the boundary

Console input/output and SQL execution are isolated. Validation and transformation functions remain pure and easy to test.

## Project Files

```text
app.py          Main menu and command functions
config.py       Immutable connection configuration
console_ui.py   Prompt and table-display functions
database.py     Connections, transactions, database creation
repository.py   Department and Employee CRUD SQL
validators.py   Pure validation and parser functions
schema.sql      Optional SQL script for SSMS
requirements.txt
README.md
```

## Connection String Mapping

The supplied SQL Server connection details are represented as:

```text
DRIVER={ODBC Driver 18 for SQL Server};
SERVER=DESKTOP-UHSE201\SQLEXPRESS;
DATABASE=EmployeeManagementDB;
Trusted_Connection=yes;
Encrypt=yes;
TrustServerCertificate=yes;
Connection Timeout=30;
ApplicationIntent=ReadWrite;
MultiSubnetFailover=no
```

## Common Errors

### Driver not found

Install **Microsoft ODBC Driver 18 for SQL Server**, or change `driver` in `config.py` to an installed driver name.

### Login failed

Confirm Windows Authentication is enabled and that the current Windows account has access to SQL Server.

### Cannot create database

Run with an account that has `CREATE ANY DATABASE`, `dbcreator`, or `sysadmin` permission. As an alternative, run `schema.sql` in SQL Server Management Studio using an authorized account.

### Cannot delete department

This is expected when employees still reference the department. Update or delete those employees first.

### Certificate error

The project already uses:

```text
Encrypt=yes;TrustServerCertificate=yes
```

This matches the supplied connection configuration for local development.

## Optional Manual SQL Setup

Open `schema.sql` in SQL Server Management Studio and execute it. The Python menu can then directly perform CRUD operations.
