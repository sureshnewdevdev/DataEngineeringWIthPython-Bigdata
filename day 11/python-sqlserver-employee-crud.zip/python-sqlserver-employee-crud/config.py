from dataclasses import dataclass


@dataclass(frozen=True)
class DatabaseConfig:
    """Immutable database configuration."""

    driver: str = "ODBC Driver 18 for SQL Server"
    server: str = r"DESKTOP-UHSE201\SQLEXPRESS"
    database: str = "EmployeeManagementDB"
    trusted_connection: bool = True
    encrypt: bool = True
    trust_server_certificate: bool = True
    connection_timeout: int = 30
    application_intent: str = "ReadWrite"
    multi_subnet_failover: bool = False


def build_connection_string(config: DatabaseConfig, database: str | None = None) -> str:
    """Pure function that converts configuration into a pyodbc connection string."""

    target_database = database or config.database
    yes_no = lambda value: "yes" if value else "no"

    return ";".join(
        (
            f"DRIVER={{{config.driver}}}",
            f"SERVER={config.server}",
            f"DATABASE={target_database}",
            f"Trusted_Connection={yes_no(config.trusted_connection)}",
            f"Encrypt={yes_no(config.encrypt)}",
            f"TrustServerCertificate={yes_no(config.trust_server_certificate)}",
            f"Connection Timeout={config.connection_timeout}",
            f"ApplicationIntent={config.application_intent}",
            f"MultiSubnetFailover={yes_no(config.multi_subnet_failover)}",
        )
    )


CONFIG = DatabaseConfig()
