USE master;
GO

IF DB_ID(N'EmployeeManagementDB') IS NULL
BEGIN
    CREATE DATABASE EmployeeManagementDB;
END;
GO

USE EmployeeManagementDB;
GO

IF OBJECT_ID(N'dbo.Department', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Department
    (
        DepartmentId   INT IDENTITY(1,1) PRIMARY KEY,
        DepartmentName NVARCHAR(100) NOT NULL UNIQUE,
        Location       NVARCHAR(100) NULL,
        CreatedAt      DATETIME2(0) NOT NULL DEFAULT SYSUTCDATETIME()
    );
END;
GO

IF OBJECT_ID(N'dbo.Employee', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Employee
    (
        EmployeeId   INT IDENTITY(1,1) PRIMARY KEY,
        FirstName    NVARCHAR(60) NOT NULL,
        LastName     NVARCHAR(60) NOT NULL,
        Email        NVARCHAR(255) NOT NULL UNIQUE,
        Salary       DECIMAL(12,2) NOT NULL CHECK (Salary >= 0),
        HireDate     DATE NOT NULL,
        DepartmentId INT NOT NULL,
        CreatedAt    DATETIME2(0) NOT NULL DEFAULT SYSUTCDATETIME(),
        UpdatedAt    DATETIME2(0) NULL,
        CONSTRAINT FK_Employee_Department
            FOREIGN KEY (DepartmentId)
            REFERENCES dbo.Department(DepartmentId)
    );

    CREATE INDEX IX_Employee_DepartmentId
        ON dbo.Employee(DepartmentId);
END;
GO
