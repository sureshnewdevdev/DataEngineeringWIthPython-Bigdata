from __future__ import annotations

from collections.abc import Callable, Iterable, Sequence
from typing import Any, TypeVar

import pyodbc

from config import CONFIG, build_connection_string

T = TypeVar("T")


def connect(database: str | None = None, *, autocommit: bool = False) -> pyodbc.Connection:
    return pyodbc.connect(
        build_connection_string(CONFIG, database),
        autocommit=autocommit,
    )


def run_read(
    query: str,
    parameters: Sequence[Any] = (),
    mapper: Callable[[pyodbc.Row], T] = lambda row: tuple(row),
) -> list[T]:
    """Execute a SELECT and transform each row with a supplied mapping function."""

    with connect() as connection:
        cursor = connection.cursor()
        rows = cursor.execute(query, parameters).fetchall()
        return list(map(mapper, rows))


def run_write(query: str, parameters: Sequence[Any] = ()) -> int:
    """Execute one data-changing statement in a transaction."""

    connection = connect()
    try:
        cursor = connection.cursor()
        cursor.execute(query, parameters)
        affected = cursor.rowcount
        connection.commit()
        return affected
    except Exception:
        connection.rollback()
        raise
    finally:
        connection.close()


def run_scalar(query: str, parameters: Sequence[Any] = ()) -> Any:
    with connect() as connection:
        row = connection.cursor().execute(query, parameters).fetchone()
        return None if row is None else row[0]


def create_database_and_tables() -> None:
    """Create the database first, then create relational tables and indexes."""

    database_name = CONFIG.database.replace("]", "]]")

    with connect("master", autocommit=True) as master_connection:
        master_connection.cursor().execute(
            f"""
            IF DB_ID(N'{CONFIG.database}') IS NULL
            BEGIN
                CREATE DATABASE [{database_name}];
            END;
            """
        )

    schema_sql = """
    IF OBJECT_ID(N'dbo.Department', N'U') IS NULL
    BEGIN
        CREATE TABLE dbo.Department
        (
            DepartmentId   INT IDENTITY(1,1) PRIMARY KEY,
            DepartmentName NVARCHAR(100) NOT NULL,
            Location       NVARCHAR(100) NULL,
            CreatedAt      DATETIME2(0) NOT NULL
                CONSTRAINT DF_Department_CreatedAt DEFAULT SYSUTCDATETIME(),
            CONSTRAINT UQ_Department_DepartmentName UNIQUE (DepartmentName)
        );
    END;

    IF OBJECT_ID(N'dbo.Employee', N'U') IS NULL
    BEGIN
        CREATE TABLE dbo.Employee
        (
            EmployeeId  INT IDENTITY(1,1) PRIMARY KEY,
            FirstName   NVARCHAR(60) NOT NULL,
            LastName    NVARCHAR(60) NOT NULL,
            Email       NVARCHAR(255) NOT NULL,
            Salary      DECIMAL(12,2) NOT NULL,
            HireDate    DATE NOT NULL,
            DepartmentId INT NOT NULL,
            CreatedAt   DATETIME2(0) NOT NULL
                CONSTRAINT DF_Employee_CreatedAt DEFAULT SYSUTCDATETIME(),
            UpdatedAt   DATETIME2(0) NULL,
            CONSTRAINT UQ_Employee_Email UNIQUE (Email),
            CONSTRAINT CK_Employee_Salary CHECK (Salary >= 0),
            CONSTRAINT FK_Employee_Department FOREIGN KEY (DepartmentId)
                REFERENCES dbo.Department(DepartmentId)
        );

        CREATE INDEX IX_Employee_DepartmentId
            ON dbo.Employee(DepartmentId);
    END;
    """

    connection = connect()
    try:
        connection.cursor().execute(schema_sql)
        connection.commit()
    except Exception:
        connection.rollback()
        raise
    finally:
        connection.close()


def seed_sample_data() -> None:
    """Insert useful demo rows only when the tables are empty."""

    sql = """
    IF NOT EXISTS (SELECT 1 FROM dbo.Department)
    BEGIN
        INSERT INTO dbo.Department (DepartmentName, Location)
        VALUES (N'Engineering', N'Coimbatore'),
               (N'Human Resources', N'Chennai'),
               (N'Finance', N'Bengaluru');
    END;

    IF NOT EXISTS (SELECT 1 FROM dbo.Employee)
    BEGIN
        INSERT INTO dbo.Employee
            (FirstName, LastName, Email, Salary, HireDate, DepartmentId)
        SELECT N'Anitha', N'Kumar', N'anitha.kumar@example.com', 65000.00,
               CAST('2025-01-15' AS DATE), DepartmentId
        FROM dbo.Department WHERE DepartmentName = N'Engineering';

        INSERT INTO dbo.Employee
            (FirstName, LastName, Email, Salary, HireDate, DepartmentId)
        SELECT N'Rahul', N'Sharma', N'rahul.sharma@example.com', 52000.00,
               CAST('2025-03-10' AS DATE), DepartmentId
        FROM dbo.Department WHERE DepartmentName = N'Finance';
    END;
    """

    connection = connect()
    try:
        connection.cursor().execute(sql)
        connection.commit()
    except Exception:
        connection.rollback()
        raise
    finally:
        connection.close()
