/*
SQL Window Functions Tutorial - Sample Database Script
Works with PostgreSQL / SQL Server with minor syntax changes.
For Oracle, use NUMBER/VARCHAR2 and DATE literal syntax if required.

Purpose:
This dataset is used to learn SQL Window Functions:
ROW_NUMBER, RANK, DENSE_RANK, NTILE, SUM OVER, AVG OVER,
LAG, LEAD, FIRST_VALUE, LAST_VALUE, PARTITION BY, ORDER BY, and ROWS frames.
*/

DROP TABLE IF EXISTS sales_orders;

CREATE TABLE sales_orders (
    order_id        INT PRIMARY KEY,
    order_date      DATE,
    region          VARCHAR(50),
    city            VARCHAR(50),
    salesperson     VARCHAR(100),
    product         VARCHAR(100),
    category        VARCHAR(50),
    quantity        INT,
    unit_price      DECIMAL(10,2),
    order_amount    DECIMAL(10,2)
);

INSERT INTO sales_orders
(order_id, order_date, region, city, salesperson, product, category, quantity, unit_price, order_amount)
VALUES
(1,  '2026-01-02', 'South', 'Bengaluru', 'Arun',   'Laptop',       'Electronics', 2, 65000, 130000),
(2,  '2026-01-04', 'South', 'Chennai',   'Priya',  'Keyboard',     'Electronics', 5, 1500,   7500),
(3,  '2026-01-05', 'West',  'Mumbai',    'Ravi',   'Office Chair', 'Furniture',   3, 8500,  25500),
(4,  '2026-01-07', 'North', 'Delhi',     'Neha',   'Monitor',      'Electronics', 4, 12000, 48000),
(5,  '2026-01-10', 'South', 'Bengaluru', 'Arun',   'Mouse',        'Electronics', 10, 800,   8000),
(6,  '2026-01-12', 'West',  'Pune',      'Ravi',   'Desk',         'Furniture',   2, 15000, 30000),
(7,  '2026-01-15', 'North', 'Delhi',     'Neha',   'Laptop',       'Electronics', 1, 68000, 68000),
(8,  '2026-01-17', 'East',  'Kolkata',   'Amit',   'Printer',      'Electronics', 2, 18000, 36000),
(9,  '2026-01-20', 'South', 'Hyderabad', 'Priya',  'Chair',        'Furniture',   6, 7000,  42000),
(10, '2026-01-22', 'West',  'Mumbai',    'Ravi',   'Monitor',      'Electronics', 3, 12500, 37500),
(11, '2026-01-25', 'North', 'Jaipur',    'Neha',   'Table',        'Furniture',   4, 9500,  38000),
(12, '2026-01-28', 'East',  'Kolkata',   'Amit',   'Laptop',       'Electronics', 1, 70000, 70000),
(13, '2026-02-01', 'South', 'Bengaluru', 'Arun',   'Desk',         'Furniture',   2, 14500, 29000),
(14, '2026-02-03', 'South', 'Chennai',   'Priya',  'Monitor',      'Electronics', 2, 11800, 23600),
(15, '2026-02-05', 'West',  'Pune',      'Ravi',   'Keyboard',     'Electronics', 8, 1400,  11200),
(16, '2026-02-07', 'North', 'Delhi',     'Neha',   'Mouse',        'Electronics', 12, 750,  9000),
(17, '2026-02-10', 'East',  'Bhubaneswar','Amit',  'Office Chair', 'Furniture',   5, 8200,  41000),
(18, '2026-02-12', 'South', 'Hyderabad', 'Priya',  'Laptop',       'Electronics', 2, 66000, 132000),
(19, '2026-02-14', 'West',  'Mumbai',    'Ravi',   'Table',        'Furniture',   3, 9200,  27600),
(20, '2026-02-16', 'North', 'Jaipur',    'Neha',   'Printer',      'Electronics', 1, 17500, 17500),
(21, '2026-02-18', 'East',  'Kolkata',   'Amit',   'Desk',         'Furniture',   2, 15500, 31000),
(22, '2026-02-20', 'South', 'Bengaluru', 'Arun',   'Monitor',      'Electronics', 3, 12100, 36300),
(23, '2026-02-22', 'West',  'Pune',      'Ravi',   'Laptop',       'Electronics', 1, 69000, 69000),
(24, '2026-02-25', 'North', 'Delhi',     'Neha',   'Office Chair', 'Furniture',   4, 8300,  33200),
(25, '2026-02-27', 'East',  'Bhubaneswar','Amit',  'Keyboard',     'Electronics', 6, 1450,  8700);

/* 1. Basic Window Aggregate */
SELECT
    order_id,
    region,
    salesperson,
    order_amount,
    SUM(order_amount) OVER() AS grand_total
FROM sales_orders;

/* 2. Region-wise total without GROUP BY */
SELECT
    order_id,
    region,
    salesperson,
    order_amount,
    SUM(order_amount) OVER(PARTITION BY region) AS region_total
FROM sales_orders;

/* 3. Running total by date */
SELECT
    order_id,
    order_date,
    order_amount,
    SUM(order_amount) OVER(
        ORDER BY order_date
        ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
    ) AS running_total
FROM sales_orders;

/* 4. Row number by region */
SELECT
    order_id,
    region,
    salesperson,
    order_amount,
    ROW_NUMBER() OVER(PARTITION BY region ORDER BY order_amount DESC) AS row_num
FROM sales_orders;

/* 5. Rank and Dense Rank */
SELECT
    order_id,
    region,
    salesperson,
    order_amount,
    RANK() OVER(PARTITION BY region ORDER BY order_amount DESC) AS sales_rank,
    DENSE_RANK() OVER(PARTITION BY region ORDER BY order_amount DESC) AS dense_sales_rank
FROM sales_orders;

/* 6. Top 2 orders per region */
WITH ranked_orders AS (
    SELECT
        order_id,
        region,
        salesperson,
        order_amount,
        ROW_NUMBER() OVER(PARTITION BY region ORDER BY order_amount DESC) AS rn
    FROM sales_orders
)
SELECT *
FROM ranked_orders
WHERE rn <= 2;

/* 7. LAG and LEAD */
SELECT
    order_id,
    order_date,
    salesperson,
    order_amount,
    LAG(order_amount) OVER(PARTITION BY salesperson ORDER BY order_date) AS previous_order_amount,
    LEAD(order_amount) OVER(PARTITION BY salesperson ORDER BY order_date) AS next_order_amount
FROM sales_orders;

/* 8. Difference from previous order */
SELECT
    order_id,
    order_date,
    salesperson,
    order_amount,
    order_amount - LAG(order_amount) OVER(PARTITION BY salesperson ORDER BY order_date) AS difference_from_previous
FROM sales_orders;

/* 9. First and last order amount by salesperson */
SELECT
    order_id,
    salesperson,
    order_date,
    order_amount,
    FIRST_VALUE(order_amount) OVER(
        PARTITION BY salesperson
        ORDER BY order_date
    ) AS first_order_amount,
    LAST_VALUE(order_amount) OVER(
        PARTITION BY salesperson
        ORDER BY order_date
        ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING
    ) AS last_order_amount
FROM sales_orders;

/* 10. Moving average of last 3 orders */
SELECT
    order_id,
    order_date,
    order_amount,
    AVG(order_amount) OVER(
        ORDER BY order_date
        ROWS BETWEEN 2 PRECEDING AND CURRENT ROW
    ) AS moving_avg_last_3_orders
FROM sales_orders;
