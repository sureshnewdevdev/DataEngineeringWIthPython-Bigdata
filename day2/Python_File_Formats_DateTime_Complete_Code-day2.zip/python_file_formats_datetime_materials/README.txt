Python File Format, Pip Lifecycle and Date/Time Study Materials
================================================================

Topic Coverage
--------------
1. Working with CSV files
2. Working with Excel files
3. Working with JSON files
4. Working with SQLite database
5. Pip lifecycle and package management
6. Date and Time modules
7. Mini project: Student Fee and Attendance Report

Folder Structure
----------------
python_file_formats_datetime_materials/
  study_materials.html
  README.txt
  requirements.txt
  data/
    students.csv
    students.xlsx
    config.json
    students.db
  src/
    01_csv_reader_writer.py
    02_json_config.py
    03_excel_read_write.py
    04_sqlite_db.py
    05_datetime_examples.py
    06_file_format_converter_project.py
    07_complete_student_report_project.py
    demo_run_all.py
  output/
    Generated files will be created here after running the examples.

How to Run
----------
Step 1: Open command prompt / terminal in this folder.

Step 2: Create virtual environment.
Windows:
  python -m venv .venv
  .venv\Scripts\activate

Mac/Linux:
  python3 -m venv .venv
  source .venv/bin/activate

Step 3: Install required package.
  pip install -r requirements.txt

Step 4: Run individual examples.
  python src/01_csv_reader_writer.py
  python src/02_json_config.py
  python src/03_excel_read_write.py
  python src/04_sqlite_db.py
  python src/05_datetime_examples.py
  python src/06_file_format_converter_project.py
  python src/07_complete_student_report_project.py

Step 5: Run all examples.
  python src/demo_run_all.py

Trainer Notes
-------------
- Start with CSV because it is simple and common in business reports.
- Move to JSON to explain configuration and API-style data.
- Use Excel for business-friendly files.
- Use SQLite DB to introduce database concepts without server setup.
- Use datetime for reporting, audit logs, due dates and scheduling.
- End with the complete mini project to connect all concepts.

Pip Lifecycle Commands
----------------------
Check pip version:
  pip --version

Install package:
  pip install openpyxl

Install from requirements file:
  pip install -r requirements.txt

List installed packages:
  pip list

Freeze environment:
  pip freeze > requirements.txt

Upgrade package:
  pip install --upgrade openpyxl

Uninstall package:
  pip uninstall openpyxl

Troubleshooting
---------------
Error: ModuleNotFoundError: No module named 'openpyxl'
Solution:
  pip install -r requirements.txt

Error: FileNotFoundError
Solution:
  Make sure you run commands from the main project folder.

Error: Permission denied when writing output files
Solution:
  Close Excel or any application using the output file, then run again.
