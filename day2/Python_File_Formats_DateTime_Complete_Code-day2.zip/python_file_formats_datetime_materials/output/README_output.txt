This folder stores generated files after running the Python examples. Some sample outputs are included because demo_run_all.py was tested successfully.
