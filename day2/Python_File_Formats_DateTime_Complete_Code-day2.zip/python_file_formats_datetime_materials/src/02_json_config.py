"""
Topic: Working with JSON files in Python
Run: python src/02_json_config.py
"""

import json
from pathlib import Path
from datetime import datetime

BASE_DIR = Path(__file__).resolve().parents[1]
CONFIG_FILE = BASE_DIR / "data" / "config.json"
OUTPUT_FILE = BASE_DIR / "output" / "runtime_config.json"


def read_json_config():
    with CONFIG_FILE.open("r", encoding="utf-8") as file:
        return json.load(file)


def update_config(config):
    config["last_run_time"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    config["run_status"] = "Success"
    return config


def write_json_config(config):
    OUTPUT_FILE.parent.mkdir(exist_ok=True)
    with OUTPUT_FILE.open("w", encoding="utf-8") as file:
        json.dump(config, file, indent=4)


if __name__ == "__main__":
    config = read_json_config()
    print("Original Config:")
    print(json.dumps(config, indent=4))

    updated_config = update_config(config)
    write_json_config(updated_config)

    print("\nUpdated runtime config created at:", OUTPUT_FILE)
