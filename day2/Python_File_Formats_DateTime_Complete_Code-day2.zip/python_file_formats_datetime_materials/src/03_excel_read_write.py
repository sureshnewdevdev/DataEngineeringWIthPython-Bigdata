"""
Topic: Working with Excel files using openpyxl
Install: pip install openpyxl
Run: python src/03_excel_read_write.py
"""

from pathlib import Path

BASE_DIR = Path(__file__).resolve().parents[1]
DATA_FILE = BASE_DIR / "data" / "students.xlsx"
OUTPUT_FILE = BASE_DIR / "output" / "students_excel_report.xlsx"

try:
    from openpyxl import Workbook, load_workbook
    from openpyxl.styles import Font, PatternFill
except ImportError:
    print("openpyxl is not installed.")
    print("Run: pip install openpyxl")
    raise


def create_excel_if_missing():
    """Create a sample Excel file if it is not already available."""
    if DATA_FILE.exists():
        return

    DATA_FILE.parent.mkdir(exist_ok=True)
    wb = Workbook()
    ws = wb.active
    ws.title = "Students"
    ws.append([
        "student_id", "name", "course", "fee_paid", "total_fee",
        "joining_date", "last_payment_date", "attendance_percent"
    ])
    ws.append(["S001", "Arun Kumar", "Python", 12000, 15000, "2026-07-01", "2026-07-03", 92])
    ws.append(["S002", "Bala Devi", "Python", 15000, 15000, "2026-07-02", "2026-07-02", 88])
    ws.append(["S003", "Charan Raj", "Data Engineering", 9000, 18000, "2026-07-03", "2026-07-05", 76])
    wb.save(DATA_FILE)


def build_excel_report():
    create_excel_if_missing()
    wb = load_workbook(DATA_FILE)
    ws = wb["Students"]

    # Add new calculated column
    pending_col = ws.max_column + 1
    ws.cell(row=1, column=pending_col).value = "pending_amount"

    for row in range(2, ws.max_row + 1):
        fee_paid = ws.cell(row=row, column=4).value
        total_fee = ws.cell(row=row, column=5).value
        ws.cell(row=row, column=pending_col).value = total_fee - fee_paid

    # Basic formatting
    for cell in ws[1]:
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor="1F4E79")

    for column_cells in ws.columns:
        max_length = max(len(str(cell.value)) if cell.value is not None else 0 for cell in column_cells)
        ws.column_dimensions[column_cells[0].column_letter].width = max_length + 3

    OUTPUT_FILE.parent.mkdir(exist_ok=True)
    wb.save(OUTPUT_FILE)
    print("Excel report created:", OUTPUT_FILE)


if __name__ == "__main__":
    build_excel_report()
