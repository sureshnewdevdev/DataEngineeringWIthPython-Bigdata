"""
Mini Project: Convert CSV to JSON and insert into SQLite DB
Run: python src/06_file_format_converter_project.py
"""

import csv
import json
import sqlite3
from pathlib import Path
from datetime import datetime

BASE_DIR = Path(__file__).resolve().parents[1]
CSV_FILE = BASE_DIR / "data" / "students.csv"
JSON_OUTPUT = BASE_DIR / "output" / "students_from_csv.json"
DB_OUTPUT = BASE_DIR / "output" / "students_from_csv.db"


def csv_to_json():
    students = []
    with CSV_FILE.open("r", newline="", encoding="utf-8") as file:
        reader = csv.DictReader(file)
        for row in reader:
            students.append(row)

    result = {
        "generated_on": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "record_count": len(students),
        "students": students
    }

    JSON_OUTPUT.parent.mkdir(exist_ok=True)
    with JSON_OUTPUT.open("w", encoding="utf-8") as file:
        json.dump(result, file, indent=4)

    print("JSON created:", JSON_OUTPUT)
    return students


def insert_into_sqlite(students):
    with sqlite3.connect(DB_OUTPUT) as conn:
        cursor = conn.cursor()
        cursor.execute("DROP TABLE IF EXISTS students")
        cursor.execute("""
        CREATE TABLE students (
            student_id TEXT PRIMARY KEY,
            name TEXT,
            course TEXT,
            fee_paid REAL,
            total_fee REAL,
            joining_date TEXT,
            last_payment_date TEXT,
            attendance_percent REAL
        )
        """)
        cursor.executemany("""
        INSERT INTO students VALUES (
            :student_id, :name, :course, :fee_paid, :total_fee,
            :joining_date, :last_payment_date, :attendance_percent
        )
        """, students)
        conn.commit()

    print("SQLite DB created:", DB_OUTPUT)


if __name__ == "__main__":
    student_rows = csv_to_json()
    insert_into_sqlite(student_rows)
