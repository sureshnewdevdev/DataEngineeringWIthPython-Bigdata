"""
Topic: Date and Time modules in Python
Run: python src/05_datetime_examples.py
"""

from datetime import datetime, date, timedelta
from zoneinfo import ZoneInfo


def basic_datetime_examples():
    today = date.today()
    now = datetime.now()

    print("Today:", today)
    print("Current Date and Time:", now)
    print("Formatted Date:", now.strftime("%d-%m-%Y %I:%M %p"))


def date_calculation_examples():
    joining_date = date(2026, 7, 1)
    today = date.today()
    days_completed = (today - joining_date).days
    next_review_date = today + timedelta(days=7)

    print("Joining Date:", joining_date)
    print("Days Completed:", days_completed)
    print("Next Review Date:", next_review_date)


def timezone_example():
    india_time = datetime.now(ZoneInfo("Asia/Kolkata"))
    london_time = datetime.now(ZoneInfo("Europe/London"))

    print("India Time:", india_time.strftime("%Y-%m-%d %H:%M:%S %Z"))
    print("London Time:", london_time.strftime("%Y-%m-%d %H:%M:%S %Z"))


if __name__ == "__main__":
    basic_datetime_examples()
    print("-" * 50)
    date_calculation_examples()
    print("-" * 50)
    timezone_example()
