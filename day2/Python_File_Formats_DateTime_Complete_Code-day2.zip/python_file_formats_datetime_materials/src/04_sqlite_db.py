"""
Topic: Working with SQLite database in Python
Run: python src/04_sqlite_db.py
"""

import sqlite3
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parents[1]
DB_FILE = BASE_DIR / "data" / "students.db"


def connect_db():
    return sqlite3.connect(DB_FILE)


def show_all_students():
    with connect_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT student_id, name, course, fee_paid, total_fee FROM students")
        rows = cursor.fetchall()
        for row in rows:
            print(row)


def show_pending_fee_report():
    query = """
    SELECT
        student_id,
        name,
        course,
        total_fee - fee_paid AS pending_amount
    FROM students
    WHERE total_fee - fee_paid > 0
    ORDER BY pending_amount DESC
    """
    with connect_db() as conn:
        cursor = conn.cursor()
        cursor.execute(query)
        rows = cursor.fetchall()
        print("\nPending Fee Report")
        for row in rows:
            print(row)


if __name__ == "__main__":
    print("All Students")
    show_all_students()
    show_pending_fee_report()
