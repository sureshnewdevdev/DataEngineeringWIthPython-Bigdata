"""
Complete Project: Student Fee and Attendance Report
Input: CSV + JSON Config
Output: Text report
Run: python src/07_complete_student_report_project.py
"""

import csv
import json
from pathlib import Path
from datetime import datetime, date

BASE_DIR = Path(__file__).resolve().parents[1]
CSV_FILE = BASE_DIR / "data" / "students.csv"
CONFIG_FILE = BASE_DIR / "data" / "config.json"
REPORT_FILE = BASE_DIR / "output" / "student_management_report.txt"


def load_config():
    with CONFIG_FILE.open("r", encoding="utf-8") as file:
        return json.load(file)


def load_students():
    students = []
    with CSV_FILE.open("r", newline="", encoding="utf-8") as file:
        reader = csv.DictReader(file)
        for row in reader:
            row["fee_paid"] = float(row["fee_paid"])
            row["total_fee"] = float(row["total_fee"])
            row["attendance_percent"] = float(row["attendance_percent"])
            students.append(row)
    return students


def build_report(config, students):
    total_collection = sum(s["fee_paid"] for s in students)
    total_fee = sum(s["total_fee"] for s in students)
    total_pending = total_fee - total_collection
    warning_percent = config["attendance_warning_percent"]

    lines = []
    lines.append(config["report_title"])
    lines.append("=" * 60)
    lines.append(f"Academy: {config['academy_name']}")
    lines.append(f"Generated On: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    lines.append(f"Currency: {config['currency']}")
    lines.append("")
    lines.append(f"Total Students: {len(students)}")
    lines.append(f"Total Fee: {total_fee}")
    lines.append(f"Total Collection: {total_collection}")
    lines.append(f"Total Pending: {total_pending}")
    lines.append("")
    lines.append("Students Requiring Attention")
    lines.append("-" * 60)

    for student in students:
        pending = student["total_fee"] - student["fee_paid"]
        if pending > 0 or student["attendance_percent"] < warning_percent:
            lines.append(
                f"{student['student_id']} | {student['name']} | Pending: {pending} | "
                f"Attendance: {student['attendance_percent']}%"
            )

    return "\n".join(lines)


def save_report(report):
    REPORT_FILE.parent.mkdir(exist_ok=True)
    REPORT_FILE.write_text(report, encoding="utf-8")
    print("Report created:", REPORT_FILE)


if __name__ == "__main__":
    config = load_config()
    students = load_students()
    report = build_report(config, students)
    save_report(report)
    print("\n" + report)
