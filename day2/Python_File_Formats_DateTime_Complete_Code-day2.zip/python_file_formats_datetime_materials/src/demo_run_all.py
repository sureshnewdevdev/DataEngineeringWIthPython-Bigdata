"""
Run all examples one by one.
Run: python src/demo_run_all.py
"""

import subprocess
import sys
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parents[1]
SCRIPTS = [
    "01_csv_reader_writer.py",
    "02_json_config.py",
    "03_excel_read_write.py",
    "04_sqlite_db.py",
    "05_datetime_examples.py",
    "06_file_format_converter_project.py",
    "07_complete_student_report_project.py",
]

for script in SCRIPTS:
    print("\n" + "=" * 80)
    print("Running", script)
    print("=" * 80)
    result = subprocess.run([sys.executable, str(BASE_DIR / "src" / script)], text=True)
    if result.returncode != 0:
        print(f"Script failed: {script}")
        break
