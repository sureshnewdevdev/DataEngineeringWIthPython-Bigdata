"""
Topic: Working with CSV files in Python
Run: python src/01_csv_reader_writer.py
"""

import csv
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parents[1]
DATA_FILE = BASE_DIR / "data" / "students.csv"
OUTPUT_FILE = BASE_DIR / "output" / "pending_fee_students.csv"


def read_students_from_csv():
    """Read CSV rows as dictionaries."""
    students = []
    with DATA_FILE.open("r", newline="", encoding="utf-8") as file:
        reader = csv.DictReader(file)
        for row in reader:
            row["fee_paid"] = float(row["fee_paid"])
            row["total_fee"] = float(row["total_fee"])
            row["attendance_percent"] = float(row["attendance_percent"])
            students.append(row)
    return students


def find_pending_fee_students(students):
    """Return students whose fee is still pending."""
    pending_students = []
    for student in students:
        pending_amount = student["total_fee"] - student["fee_paid"]
        if pending_amount > 0:
            student["pending_amount"] = pending_amount
            pending_students.append(student)
    return pending_students


def write_pending_students_to_csv(pending_students):
    """Write filtered data to a new CSV file."""
    OUTPUT_FILE.parent.mkdir(exist_ok=True)
    fieldnames = [
        "student_id", "name", "course", "fee_paid", "total_fee",
        "pending_amount", "joining_date", "last_payment_date", "attendance_percent"
    ]
    with OUTPUT_FILE.open("w", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(file, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(pending_students)


if __name__ == "__main__":
    students = read_students_from_csv()
    pending_students = find_pending_fee_students(students)
    write_pending_students_to_csv(pending_students)

    print("CSV Example Completed")
    print(f"Total Students: {len(students)}")
    print(f"Pending Fee Students: {len(pending_students)}")
    print(f"Output File: {OUTPUT_FILE}")
